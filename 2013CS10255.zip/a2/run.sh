g++ -std=c++11 -O3 -w main.cpp -o a.out
./a.out OCRdataset-2/potentials/trans.dat OCRdataset-2/potentials/ocr.dat OCRdataset-2/data/data-tree.dat OCRdataset-2/data/truth-tree.dat
./a.out OCRdataset-2/potentials/trans.dat OCRdataset-2/potentials/ocr.dat OCRdataset-2/data/data-treeWS.dat OCRdataset-2/data/truth-treeWS.dat
./a.out OCRdataset-2/potentials/trans.dat OCRdataset-2/potentials/ocr.dat OCRdataset-2/data/data-loops.dat OCRdataset-2/data/truth-loops.dat
./a.out OCRdataset-2/potentials/trans.dat OCRdataset-2/potentials/ocr.dat OCRdataset-2/data/data-loopsWS.dat OCRdataset-2/data/truth-loopsWS.dat
